// backend/config/database.ts
// PSU CRM & PM System — Neon PostgreSQL Connection

import { drizzle } from 'drizzle-orm/neon-http';
import { neon }    from '@neondatabase/serverless';
import * as schema from '../src/models/schema';

if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL environment variable is required');
}

const sql = neon(process.env.DATABASE_URL);
export const db = drizzle(sql, { schema });

export async function connectDatabase(): Promise<void> {
  // Test the connection
  await sql`SELECT 1`;
}
