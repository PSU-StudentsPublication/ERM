// backend/src/routes/ai.routes.ts
import { Router } from 'express';
import { AIController } from '../controllers/ai.controller';
import { authenticate } from '../middleware/auth.middleware';
import rateLimit        from 'express-rate-limit';

const router = Router();
router.use(authenticate);

// Stricter rate limit for AI routes (cost control)
const aiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 min
  max: 20,
  message: { success: false, message: 'AI request limit reached — wait a moment.' },
});
router.use(aiLimiter);

router.post('/chat',             AIController.chat);
router.post('/summarize',        AIController.summarize);
router.post('/draft-email',      AIController.draftEmail);
router.post('/recommend-tasks',  AIController.recommendTasks);
router.post('/analyze-project',  AIController.analyzeProject);

export default router;
