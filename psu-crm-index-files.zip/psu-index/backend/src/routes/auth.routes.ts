// backend/src/routes/auth.routes.ts
// PSU CRM & PM System — Authentication Routes

import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { AuthController } from '../controllers/auth.controller';
import { authenticate } from '../middleware/auth.middleware';
import { validate }     from '../middleware/validate.middleware';
import {
  loginSchema,
  registerSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
} from '../validators/auth.validators';

const router = Router();

// ─── Strict rate limiter for auth ─────────────────
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,  // 15 min
  max: 10,
  message: { success: false, message: 'Too many login attempts — try again in 15 minutes.' },
});

// ─── Public Routes ────────────────────────────────
router.post('/register',       validate(registerSchema),       AuthController.register);
router.post('/login',          authLimiter, validate(loginSchema), AuthController.login);
router.post('/refresh',        AuthController.refresh);
router.post('/forgot-password',validate(forgotPasswordSchema), AuthController.forgotPassword);
router.post('/reset-password', validate(resetPasswordSchema),  AuthController.resetPassword);
router.get( '/verify-email',   AuthController.verifyEmail);

// ─── OAuth Routes ─────────────────────────────────
router.get( '/google',          AuthController.googleLogin);
router.get( '/google/callback', AuthController.googleCallback);

// ─── Protected Routes ─────────────────────────────
router.use(authenticate);
router.get( '/me',             AuthController.getMe);
router.post('/logout',         AuthController.logout);
router.patch('/profile',       AuthController.updateProfile);
router.patch('/change-password', AuthController.changePassword);

export default router;
