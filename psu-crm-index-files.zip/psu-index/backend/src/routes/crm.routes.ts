// backend/src/routes/crm.routes.ts
import { Router } from 'express';
import { CRMController } from '../controllers/crm.controller';
import { authenticate }  from '../middleware/auth.middleware';
import { authorize }     from '../middleware/rbac.middleware';

const router = Router();
router.use(authenticate);

router.get('/customers',              CRMController.getAll);
router.post('/customers',             authorize('manager','admin','super_admin'), CRMController.create);
router.get('/customers/:id',          CRMController.getById);
router.patch('/customers/:id',        CRMController.update);
router.delete('/customers/:id',       authorize('admin','super_admin'), CRMController.remove);
router.post('/customers/:id/notes',   CRMController.addNote);
router.get('/pipeline',               CRMController.getPipeline);
router.get('/analytics',              CRMController.getAnalytics);

export default router;
