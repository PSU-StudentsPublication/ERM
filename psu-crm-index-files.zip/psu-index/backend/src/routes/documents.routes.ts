// backend/src/routes/documents.routes.ts
import { Router } from 'express';
import { DocumentsController } from '../controllers/documents.controller';
import { authenticate }        from '../middleware/auth.middleware';
import { upload }              from '../middleware/upload.middleware';

const router = Router();
router.use(authenticate);

router.get('/',           DocumentsController.getAll);
router.post('/upload',    upload.single('file'), DocumentsController.upload);
router.get('/:id',        DocumentsController.getById);
router.get('/:id/download', DocumentsController.download);
router.delete('/:id',     DocumentsController.remove);
router.patch('/:id/tags', DocumentsController.updateTags);

export default router;
