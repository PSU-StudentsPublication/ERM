// backend/src/routes/projects.routes.ts
// PSU CRM & PM System — Project Routes

import { Router } from 'express';
import { ProjectsController } from '../controllers/projects.controller';
import { authenticate }       from '../middleware/auth.middleware';
import { authorize }          from '../middleware/rbac.middleware';
import { upload }             from '../middleware/upload.middleware';

const router = Router();
router.use(authenticate);

// CRUD
router.get('/',         ProjectsController.getAll);
router.post('/',        authorize('manager','admin','super_admin'), ProjectsController.create);
router.get('/:id',      ProjectsController.getById);
router.patch('/:id',    authorize('manager','admin','super_admin'), ProjectsController.update);
router.delete('/:id',   authorize('admin','super_admin'),           ProjectsController.remove);

// Team
router.get('/:id/team',       ProjectsController.getTeam);
router.post('/:id/team',      authorize('manager','admin','super_admin'), ProjectsController.addMember);
router.delete('/:id/team/:userId', authorize('manager','admin','super_admin'), ProjectsController.removeMember);

// Tasks & Files
router.get('/:id/tasks',  ProjectsController.getTasks);
router.post('/:id/files', upload.single('file'), ProjectsController.uploadFile);
router.get('/:id/files',  ProjectsController.getFiles);

// Comments
router.get('/:id/comments',  ProjectsController.getComments);
router.post('/:id/comments', ProjectsController.addComment);

export default router;
