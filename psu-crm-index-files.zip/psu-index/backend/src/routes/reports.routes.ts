// backend/src/routes/reports.routes.ts
import { Router } from 'express';
import { ReportsController } from '../controllers/reports.controller';
import { authenticate }      from '../middleware/auth.middleware';
import { authorize }         from '../middleware/rbac.middleware';

const router = Router();
router.use(authenticate);
router.use(authorize('manager','admin','super_admin'));

router.get('/projects',       ReportsController.projects);
router.get('/tasks',          ReportsController.tasks);
router.get('/crm',            ReportsController.crm);
router.get('/team',           ReportsController.team);
router.get('/budget',         ReportsController.budget);
router.get('/export/:type',   ReportsController.export); // type: pdf | excel | csv

export default router;
