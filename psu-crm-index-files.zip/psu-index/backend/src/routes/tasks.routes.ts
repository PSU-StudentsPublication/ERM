// backend/src/routes/tasks.routes.ts
import { Router } from 'express';
import { TasksController } from '../controllers/tasks.controller';
import { authenticate }    from '../middleware/auth.middleware';
import { authorize }       from '../middleware/rbac.middleware';

const router = Router();
router.use(authenticate);

router.get('/',                 TasksController.getAll);
router.post('/',                TasksController.create);
router.get('/:id',              TasksController.getById);
router.patch('/:id',            TasksController.update);
router.delete('/:id',           authorize('manager','admin','super_admin'), TasksController.remove);
router.patch('/:id/status',     TasksController.updateStatus);
router.patch('/reorder',        TasksController.reorder);
router.get('/:id/comments',     TasksController.getComments);
router.post('/:id/comments',    TasksController.addComment);
router.patch('/:id/checklist',  TasksController.updateChecklist);

export default router;
