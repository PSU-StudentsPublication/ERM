// backend/src/routes/team.routes.ts
import { Router } from 'express';
import { TeamController } from '../controllers/team.controller';
import { authenticate }   from '../middleware/auth.middleware';
import { authorize }      from '../middleware/rbac.middleware';

const router = Router();
router.use(authenticate);

router.get('/',         TeamController.getAll);
router.post('/invite',  authorize('admin','super_admin'), TeamController.invite);
router.get('/:id',      TeamController.getById);
router.patch('/:id',    authorize('admin','super_admin'), TeamController.update);
router.delete('/:id',   authorize('super_admin'),         TeamController.remove);
router.patch('/:id/role', authorize('admin','super_admin'), TeamController.updateRole);

export default router;
