// frontend/src/app/(dashboard)/ai/page.tsx
import type { Metadata } from 'next';
import { AIView } from '@/components/ai/AIView';
export const metadata: Metadata = { title: 'AI Assistant' };
export default function AIPage() { return <AIView />; }
