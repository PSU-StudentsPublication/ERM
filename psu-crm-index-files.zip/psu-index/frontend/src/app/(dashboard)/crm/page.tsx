// frontend/src/app/(dashboard)/crm/page.tsx
import type { Metadata } from 'next';
import { CRMView } from '@/components/crm/CRMView';
export const metadata: Metadata = { title: 'CRM' };
export default function CRMPage() { return <CRMView />; }
