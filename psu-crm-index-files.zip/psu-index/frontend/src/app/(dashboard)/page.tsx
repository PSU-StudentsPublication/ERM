// frontend/src/app/(dashboard)/page.tsx
// PSU CRM & PM System — Main Dashboard Page
// Author: Roise Uddin <r.uddin@psu.edu>

import type { Metadata } from 'next';
import { DashboardView } from '@/components/dashboard/DashboardView';

export const metadata: Metadata = {
  title: 'Dashboard',
  description: 'PSU CRM & PM System — Overview dashboard',
};

export default function DashboardPage() {
  return <DashboardView />;
}
