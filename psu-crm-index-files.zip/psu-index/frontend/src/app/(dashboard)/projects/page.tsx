// frontend/src/app/(dashboard)/projects/page.tsx
import type { Metadata } from 'next';
import { ProjectsView } from '@/components/projects/ProjectsView';

export const metadata: Metadata = { title: 'Projects' };
export default function ProjectsPage() { return <ProjectsView />; }
