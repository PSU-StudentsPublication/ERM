// frontend/src/app/(dashboard)/reports/page.tsx
import type { Metadata } from 'next';
import { ReportsView } from '@/components/reports/ReportsView';
export const metadata: Metadata = { title: 'Reports' };
export default function ReportsPage() { return <ReportsView />; }
