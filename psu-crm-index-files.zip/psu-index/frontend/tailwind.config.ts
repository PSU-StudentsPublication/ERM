// frontend/tailwind.config.ts
import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: 'class',
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        psu: {
          primary: '#1a5c38',
          dark:    '#0f3d20',
          medium:  '#236b44',
          light:   '#4aaa6b',
          pale:    '#e8f5ee',
          gold:    '#b8860b',
        },
      },
      fontFamily: {
        sans:    ['var(--font-inter)', 'system-ui', 'sans-serif'],
        serif:   ['Georgia', 'Times New Roman', 'serif'],
        mono:    ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      borderRadius: {
        sm:   '6px',
        md:   '10px',
        lg:   '14px',
        xl:   '20px',
        '2xl':'28px',
      },
      boxShadow: {
        sm: '0 1px 4px rgba(0,0,0,0.04)',
        md: '0 4px 16px rgba(26,92,56,0.10)',
        lg: '0 8px 32px rgba(0,0,0,0.12)',
      },
      animation: {
        'fade-in':    'fadeIn 0.25s ease forwards',
        'slide-left': 'slideInLeft 0.25s ease forwards',
        'spin-slow':  'spin 2s linear infinite',
      },
      keyframes: {
        fadeIn: {
          from: { opacity: '0', transform: 'translateY(6px)' },
          to:   { opacity: '1', transform: 'translateY(0)' },
        },
        slideInLeft: {
          from: { opacity: '0', transform: 'translateX(-16px)' },
          to:   { opacity: '1', transform: 'translateX(0)' },
        },
      },
    },
  },
  plugins: [],
};

export default config;
