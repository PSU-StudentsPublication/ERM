# Contributing to PSU CRM & PM System

Thank you for your interest in contributing to the PSU CRM & Project Management System!

## Development Setup

1. Fork the repository and clone your fork
2. Create a feature branch: `git checkout -b feature/your-feature`
3. Install dependencies: `npm install`
4. Copy environment: `cp .env.example .env`
5. Start dev servers: `npm run dev`

## Code Standards

- **TypeScript** everywhere — no implicit `any`
- **Conventional Commits** for all commit messages
- **ESLint + Prettier** enforced via pre-commit hooks
- **Zod** for all runtime validation

## Commit Format

```
feat(crm): add lead scoring system
fix(auth): resolve JWT refresh race condition
docs: update API reference for projects endpoint
chore(deps): update recharts to v2.12
```

## Pull Request Guidelines

- Keep PRs focused — one feature or fix per PR
- Add/update tests for all new functionality
- Ensure CI passes before requesting review
- Update documentation if changing public APIs

## Reporting Bugs

Use the GitHub Issue tracker with the **bug report** template.

## Author

**Roise Uddin** — Adjunct Instructor, IEEE Senior Member  
Pacific States University, Los Angeles  
[linkedin.com/in/roiseuddinr](https://linkedin.com/in/roiseuddinr)
