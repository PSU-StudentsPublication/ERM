// backend/src/models/schema.ts
// PSU CRM & PM System — Drizzle ORM Schema
// Author: Roise Uddin <r.uddin@psu.edu>

import {
  pgTable,
  uuid,
  varchar,
  text,
  boolean,
  integer,
  numeric,
  date,
  timestamp,
  inet,
  jsonb,
  bigint,
  index,
  uniqueIndex,
  primaryKey,
} from 'drizzle-orm/pg-core';
import { relations, sql } from 'drizzle-orm';

// ─── Timestamps helper ────────────────────────────
const timestamps = {
  createdAt: timestamp('created_at', { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
};

// ─── Users ────────────────────────────────────────
export const users = pgTable(
  'users',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    name: varchar('name', { length: 100 }).notNull(),
    email: varchar('email', { length: 255 }).notNull().unique(),
    password: varchar('password', { length: 255 }),
    role: varchar('role', { length: 50 }).notNull().default('staff'),
    // Roles: super_admin | admin | manager | staff | student | client
    department: varchar('department', { length: 100 }),
    avatarUrl: text('avatar_url'),
    isActive: boolean('is_active').notNull().default(true),
    isEmailVerified: boolean('is_email_verified').notNull().default(false),
    emailVerifyToken: varchar('email_verify_token', { length: 255 }),
    passwordResetToken: varchar('password_reset_token', { length: 255 }),
    passwordResetExpiry: timestamp('password_reset_expiry', { withTimezone: true }),
    lastLogin: timestamp('last_login', { withTimezone: true }),
    googleId: varchar('google_id', { length: 100 }),
    ...timestamps,
  },
  (table) => ({
    emailIdx: uniqueIndex('users_email_idx').on(table.email),
    roleIdx: index('users_role_idx').on(table.role),
  })
);

// ─── Projects ─────────────────────────────────────
export const projects = pgTable(
  'projects',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    name: varchar('name', { length: 200 }).notNull(),
    description: text('description'),
    status: varchar('status', { length: 50 }).notNull().default('pending'),
    // Statuses: pending | in_progress | on_hold | completed
    priority: varchar('priority', { length: 20 }).notNull().default('medium'),
    // Priorities: high | medium | low
    progress: integer('progress').notNull().default(0),
    budget: numeric('budget', { precision: 12, scale: 2 }),
    spent: numeric('spent', { precision: 12, scale: 2 }).default('0'),
    startDate: date('start_date'),
    deadline: date('deadline'),
    ownerId: uuid('owner_id').references(() => users.id, { onDelete: 'set null' }),
    ...timestamps,
  },
  (table) => ({
    statusIdx: index('projects_status_idx').on(table.status),
    ownerIdx: index('projects_owner_idx').on(table.ownerId),
    deadlineIdx: index('projects_deadline_idx').on(table.deadline),
  })
);

// ─── Project Members (junction) ───────────────────
export const projectMembers = pgTable(
  'project_members',
  {
    projectId: uuid('project_id')
      .notNull()
      .references(() => projects.id, { onDelete: 'cascade' }),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    role: varchar('role', { length: 50 }).notNull().default('member'),
    joinedAt: timestamp('joined_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.projectId, table.userId] }),
  })
);

// ─── Tasks ────────────────────────────────────────
export const tasks = pgTable(
  'tasks',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    projectId: uuid('project_id').references(() => projects.id, { onDelete: 'cascade' }),
    title: varchar('title', { length: 300 }).notNull(),
    description: text('description'),
    status: varchar('status', { length: 50 }).notNull().default('todo'),
    // Statuses: todo | in_progress | review | completed
    priority: varchar('priority', { length: 20 }).notNull().default('medium'),
    assigneeId: uuid('assignee_id').references(() => users.id, { onDelete: 'set null' }),
    createdBy: uuid('created_by').references(() => users.id, { onDelete: 'set null' }),
    dueDate: date('due_date'),
    position: integer('position').notNull().default(0),
    parentId: uuid('parent_id'),
    isRecurring: boolean('is_recurring').notNull().default(false),
    recurringPattern: varchar('recurring_pattern', { length: 50 }),
    estimatedHours: numeric('estimated_hours', { precision: 6, scale: 2 }),
    loggedHours: numeric('logged_hours', { precision: 6, scale: 2 }).default('0'),
    checklist: jsonb('checklist').default([]),
    tags: text('tags').array().default([]),
    ...timestamps,
  },
  (table) => ({
    projectIdx: index('tasks_project_idx').on(table.projectId),
    assigneeIdx: index('tasks_assignee_idx').on(table.assigneeId),
    statusIdx: index('tasks_status_idx').on(table.status),
    positionIdx: index('tasks_position_idx').on(table.projectId, table.status, table.position),
  })
);

// ─── Task Comments ────────────────────────────────
export const taskComments = pgTable('task_comments', {
  id: uuid('id').primaryKey().defaultRandom(),
  taskId: uuid('task_id')
    .notNull()
    .references(() => tasks.id, { onDelete: 'cascade' }),
  userId: uuid('user_id')
    .notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  body: text('body').notNull(),
  ...timestamps,
});

// ─── CRM Customers ────────────────────────────────
export const customers = pgTable(
  'customers',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    companyName: varchar('company_name', { length: 200 }).notNull(),
    contactName: varchar('contact_name', { length: 100 }),
    email: varchar('email', { length: 255 }),
    phone: varchar('phone', { length: 50 }),
    website: varchar('website', { length: 255 }),
    industry: varchar('industry', { length: 100 }),
    stage: varchar('stage', { length: 50 }).notNull().default('cold_lead'),
    // Stages: cold_lead | active_lead | proposal | negotiation | client
    dealValue: numeric('deal_value', { precision: 12, scale: 2 }),
    notes: text('notes'),
    assignedTo: uuid('assigned_to').references(() => users.id, { onDelete: 'set null' }),
    lastContactedAt: timestamp('last_contacted_at', { withTimezone: true }),
    nextFollowUpAt: timestamp('next_follow_up_at', { withTimezone: true }),
    ...timestamps,
  },
  (table) => ({
    stageIdx: index('customers_stage_idx').on(table.stage),
    assignedIdx: index('customers_assigned_idx').on(table.assignedTo),
  })
);

// ─── Documents ────────────────────────────────────
export const documents = pgTable(
  'documents',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    name: varchar('name', { length: 255 }).notNull(),
    type: varchar('type', { length: 50 }),
    mimeType: varchar('mime_type', { length: 100 }),
    sizeBytes: bigint('size_bytes', { mode: 'number' }),
    s3Key: text('s3_key').notNull(),
    s3Url: text('s3_url'),
    projectId: uuid('project_id').references(() => projects.id, { onDelete: 'set null' }),
    uploadedBy: uuid('uploaded_by').references(() => users.id, { onDelete: 'set null' }),
    version: integer('version').notNull().default(1),
    tags: text('tags').array().default([]),
    isDeleted: boolean('is_deleted').notNull().default(false),
    ...timestamps,
  }
);

// ─── Notifications ────────────────────────────────
export const notifications = pgTable(
  'notifications',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    type: varchar('type', { length: 50 }).notNull(),
    title: varchar('title', { length: 255 }).notNull(),
    body: text('body'),
    isRead: boolean('is_read').notNull().default(false),
    link: text('link'),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    userIdx: index('notifications_user_idx').on(table.userId, table.isRead),
  })
);

// ─── Audit Logs ───────────────────────────────────
export const auditLogs = pgTable(
  'audit_logs',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id').references(() => users.id, { onDelete: 'set null' }),
    action: varchar('action', { length: 100 }).notNull(),
    entity: varchar('entity', { length: 100 }),
    entityId: uuid('entity_id'),
    changes: jsonb('changes'),
    ipAddress: inet('ip_address'),
    userAgent: text('user_agent'),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    userIdx: index('audit_user_idx').on(table.userId),
    entityIdx: index('audit_entity_idx').on(table.entity, table.entityId),
    dateIdx: index('audit_date_idx').on(table.createdAt),
  })
);

// ─── Relations ────────────────────────────────────
export const usersRelations = relations(users, ({ many }) => ({
  ownedProjects: many(projects),
  projectMemberships: many(projectMembers),
  assignedTasks: many(tasks),
  comments: many(taskComments),
  assignedCustomers: many(customers),
  notifications: many(notifications),
  uploadedDocuments: many(documents),
}));

export const projectsRelations = relations(projects, ({ one, many }) => ({
  owner: one(users, { fields: [projects.ownerId], references: [users.id] }),
  members: many(projectMembers),
  tasks: many(tasks),
  documents: many(documents),
}));

export const tasksRelations = relations(tasks, ({ one, many }) => ({
  project: one(projects, { fields: [tasks.projectId], references: [projects.id] }),
  assignee: one(users, { fields: [tasks.assigneeId], references: [users.id] }),
  comments: many(taskComments),
}));

// ─── Type exports ─────────────────────────────────
export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type Project = typeof projects.$inferSelect;
export type NewProject = typeof projects.$inferInsert;
export type Task = typeof tasks.$inferSelect;
export type NewTask = typeof tasks.$inferInsert;
export type Customer = typeof customers.$inferSelect;
export type NewCustomer = typeof customers.$inferInsert;
export type Document = typeof documents.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type AuditLog = typeof auditLogs.$inferSelect;
