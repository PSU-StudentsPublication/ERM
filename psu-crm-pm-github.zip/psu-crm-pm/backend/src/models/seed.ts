// backend/src/models/seed.ts
// PSU CRM & PM System — Sample Seed Data
// Run: npm run db:seed

import { db } from '../../config/database';
import { users, projects, projectMembers, tasks, customers } from './schema';
import bcrypt from 'bcryptjs';

async function seed() {
  console.log('🌱 Seeding PSU CRM & PM database...');

  // ─── Users ──────────────────────────────────────
  const hashedPassword = await bcrypt.hash('PSU@admin2025', 12);

  const [admin, manager, staff1, staff2, intern] = await db
    .insert(users)
    .values([
      {
        name: 'Roise Uddin',
        email: 'admin@psu.edu',
        password: hashedPassword,
        role: 'super_admin',
        department: 'Engineering',
        isEmailVerified: true,
      },
      {
        name: 'Nasifa Rumali',
        email: 'manager@psu.edu',
        password: await bcrypt.hash('PSU@manager2025', 12),
        role: 'manager',
        department: 'Operations',
        isEmailVerified: true,
      },
      {
        name: 'Alex Nguyen',
        email: 'staff@psu.edu',
        password: await bcrypt.hash('PSU@staff2025', 12),
        role: 'staff',
        department: 'Development',
        isEmailVerified: true,
      },
      {
        name: 'Maria Kim',
        email: 'm.kim@psu.edu',
        password: await bcrypt.hash('PSU@staff2025', 12),
        role: 'admin',
        department: 'IT',
        isEmailVerified: true,
      },
      {
        name: 'Sara Patel',
        email: 's.patel@psu.edu',
        password: await bcrypt.hash('PSU@staff2025', 12),
        role: 'student',
        department: 'Engineering',
        isEmailVerified: true,
      },
    ])
    .returning();

  console.log('✅ Users seeded:', [admin, manager, staff1, staff2, intern].length);

  // ─── Projects ───────────────────────────────────
  const [proj1, proj2, proj3] = await db
    .insert(projects)
    .values([
      {
        name: 'ENPS Newsroom System',
        description: 'Full-stack Electronic News Production System for Desh TV',
        status: 'in_progress',
        priority: 'high',
        progress: 75,
        budget: '45000',
        spent: '32000',
        deadline: '2026-06-15',
        ownerId: admin.id,
      },
      {
        name: 'PSU Main Homepage Redesign',
        description: 'Complete redesign of Pacific States University website',
        status: 'in_progress',
        priority: 'high',
        progress: 60,
        budget: '12000',
        spent: '8500',
        deadline: '2026-05-30',
        ownerId: admin.id,
      },
      {
        name: 'CRM Implementation',
        description: 'Enterprise CRM & PM system for PSU',
        status: 'pending',
        priority: 'high',
        progress: 15,
        budget: '65000',
        spent: '9750',
        deadline: '2026-08-01',
        ownerId: manager.id,
      },
    ])
    .returning();

  // ─── Project Members ────────────────────────────
  await db.insert(projectMembers).values([
    { projectId: proj1.id, userId: admin.id, role: 'owner' },
    { projectId: proj1.id, userId: staff1.id, role: 'member' },
    { projectId: proj1.id, userId: staff2.id, role: 'member' },
    { projectId: proj2.id, userId: admin.id, role: 'owner' },
    { projectId: proj2.id, userId: staff1.id, role: 'member' },
    { projectId: proj3.id, userId: manager.id, role: 'owner' },
    { projectId: proj3.id, userId: admin.id, role: 'member' },
    { projectId: proj3.id, userId: staff2.id, role: 'member' },
  ]);

  console.log('✅ Projects + members seeded');

  // ─── Tasks ──────────────────────────────────────
  await db.insert(tasks).values([
    {
      projectId: proj1.id,
      title: 'Implement JWT authentication flow',
      status: 'in_progress',
      priority: 'high',
      assigneeId: admin.id,
      createdBy: admin.id,
      dueDate: '2026-05-22',
      position: 0,
    },
    {
      projectId: proj1.id,
      title: 'Build Kanban drag-and-drop UI',
      status: 'in_progress',
      priority: 'high',
      assigneeId: staff1.id,
      createdBy: admin.id,
      dueDate: '2026-05-23',
      position: 1,
    },
    {
      projectId: proj1.id,
      title: 'User role permissions system',
      status: 'review',
      priority: 'high',
      assigneeId: staff2.id,
      createdBy: manager.id,
      dueDate: '2026-05-20',
      position: 0,
    },
    {
      projectId: proj1.id,
      title: 'Initial project setup & CI/CD',
      status: 'completed',
      priority: 'medium',
      assigneeId: admin.id,
      createdBy: admin.id,
      dueDate: '2026-05-15',
      position: 0,
    },
    {
      projectId: proj2.id,
      title: 'Design database schema for CRM module',
      status: 'todo',
      priority: 'high',
      assigneeId: admin.id,
      createdBy: admin.id,
      dueDate: '2026-05-25',
      position: 0,
    },
    {
      projectId: proj2.id,
      title: 'Setup Docker containerization',
      status: 'todo',
      priority: 'medium',
      assigneeId: staff2.id,
      createdBy: manager.id,
      dueDate: '2026-05-28',
      position: 1,
    },
  ]);

  console.log('✅ Tasks seeded');

  // ─── Customers ──────────────────────────────────
  await db.insert(customers).values([
    {
      companyName: 'Desh Media Group',
      contactName: 'Ahmed Rahman',
      email: 'a.rahman@deshmedia.com',
      phone: '+880-1711-234567',
      industry: 'Media',
      stage: 'client',
      dealValue: '125000',
      assignedTo: admin.id,
    },
    {
      companyName: 'Pacific Tech Solutions',
      contactName: 'Sarah Chen',
      email: 's.chen@pactech.com',
      phone: '+1-213-555-0123',
      industry: 'Technology',
      stage: 'negotiation',
      dealValue: '48000',
      assignedTo: manager.id,
    },
    {
      companyName: 'GlobalEd Foundation',
      contactName: 'Dr. James Osei',
      email: 'j.osei@globaled.org',
      industry: 'Education',
      stage: 'proposal',
      dealValue: '75000',
      assignedTo: admin.id,
    },
    {
      companyName: 'KU Foundation',
      contactName: 'Prof. Kim Min-jun',
      email: 'minjun@kuf.ac.kr',
      industry: 'Education',
      stage: 'client',
      dealValue: '180000',
      assignedTo: admin.id,
    },
    {
      companyName: 'NetSec Alliance',
      contactName: 'Priya Sharma',
      email: 'p.sharma@netsec.io',
      industry: 'Cybersecurity',
      stage: 'cold_lead',
      dealValue: '35000',
      assignedTo: staff1.id,
    },
  ]);

  console.log('✅ Customers seeded');
  console.log('\n🎉 Database seeded successfully!');
  console.log('\n📋 Login credentials:');
  console.log('  Super Admin → admin@psu.edu / PSU@admin2025');
  console.log('  Manager     → manager@psu.edu / PSU@manager2025');
  console.log('  Staff       → staff@psu.edu / PSU@staff2025');

  process.exit(0);
}

seed().catch((err) => {
  console.error('❌ Seed failed:', err);
  process.exit(1);
});
