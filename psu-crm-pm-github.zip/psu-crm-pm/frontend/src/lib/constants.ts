// frontend/src/lib/constants.ts
// PSU CRM & PM System — Brand & App Constants

// ─── PSU Brand Colors ──────────────────────────────
export const PSU_COLORS = {
  primary: '#1a5c38',     // PSU Forest Green
  dark:    '#0f3d20',     // Deep Green (sidebar)
  medium:  '#236b44',     // Medium Green
  light:   '#4aaa6b',     // Light Accent
  pale:    '#e8f5ee',     // Very Light Green
  gold:    '#b8860b',     // PSU Gold (honor/awards)
  white:   '#ffffff',
} as const;

// ─── User Roles ────────────────────────────────────
export const USER_ROLES = {
  SUPER_ADMIN: 'super_admin',
  ADMIN:       'admin',
  MANAGER:     'manager',
  STAFF:       'staff',
  STUDENT:     'student',
  CLIENT:      'client',
} as const;

export type UserRole = typeof USER_ROLES[keyof typeof USER_ROLES];

// ─── Project Statuses ─────────────────────────────
export const PROJECT_STATUS = {
  PENDING:     'pending',
  IN_PROGRESS: 'in_progress',
  ON_HOLD:     'on_hold',
  COMPLETED:   'completed',
} as const;

// ─── Task Statuses ────────────────────────────────
export const TASK_STATUS = {
  TODO:        'todo',
  IN_PROGRESS: 'in_progress',
  REVIEW:      'review',
  COMPLETED:   'completed',
} as const;

// ─── CRM Pipeline Stages ──────────────────────────
export const CRM_STAGES = [
  'cold_lead',
  'active_lead',
  'proposal',
  'negotiation',
  'client',
] as const;

// ─── Priority Levels ──────────────────────────────
export const PRIORITY = {
  HIGH:   'high',
  MEDIUM: 'medium',
  LOW:    'low',
} as const;

// ─── Status Badge Colors ──────────────────────────
export const STATUS_COLORS: Record<string, { bg: string; text: string }> = {
  // Project / Task status
  pending:     { bg: '#fef9c3', text: '#a16207' },
  in_progress: { bg: '#dbeafe', text: '#1d4ed8' },
  on_hold:     { bg: '#f3f4f6', text: '#374151' },
  completed:   { bg: '#dcfce7', text: '#15803d' },
  todo:        { bg: '#f3f4f6', text: '#374151' },
  review:      { bg: '#ede9fe', text: '#6d28d9' },
  // Priority
  high:        { bg: '#fee2e2', text: '#b91c1c' },
  medium:      { bg: '#fef9c3', text: '#a16207' },
  low:         { bg: '#dcfce7', text: '#15803d' },
  // CRM
  cold_lead:   { bg: '#f3f4f6', text: '#374151' },
  active_lead: { bg: '#ffedd5', text: '#c2410c' },
  proposal:    { bg: '#ede9fe', text: '#6d28d9' },
  negotiation: { bg: '#dbeafe', text: '#1d4ed8' },
  client:      { bg: '#dcfce7', text: '#15803d' },
};

// ─── Navigation Items ─────────────────────────────
export const NAV_ITEMS = [
  { id: 'dashboard',  label: 'Dashboard',     icon: 'LayoutDashboard', href: '/' },
  { id: 'projects',   label: 'Projects',       icon: 'FolderOpen',     href: '/projects' },
  { id: 'tasks',      label: 'Tasks',          icon: 'CheckSquare',    href: '/tasks' },
  { id: 'crm',        label: 'CRM',            icon: 'Briefcase',      href: '/crm' },
  { id: 'team',       label: 'Team',           icon: 'Users',          href: '/team' },
  { id: 'documents',  label: 'Documents',      icon: 'FileText',       href: '/documents' },
  { id: 'reports',    label: 'Reports',        icon: 'BarChart2',      href: '/reports' },
  { id: 'ai',         label: 'AI Assistant',   icon: 'Zap',            href: '/ai' },
  { id: 'messages',   label: 'Messages',       icon: 'MessageSquare',  href: '/messages' },
  { id: 'settings',   label: 'Settings',       icon: 'Settings',       href: '/settings' },
] as const;

// ─── File Types ───────────────────────────────────
export const ALLOWED_FILE_TYPES = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'image/jpeg',
  'image/png',
  'image/gif',
  'image/webp',
  'video/mp4',
  'video/quicktime',
] as const;

export const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB

// ─── API Endpoints ────────────────────────────────
export const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api';

export const ENDPOINTS = {
  AUTH: {
    LOGIN:           `${API_BASE}/auth/login`,
    REGISTER:        `${API_BASE}/auth/register`,
    REFRESH:         `${API_BASE}/auth/refresh`,
    LOGOUT:          `${API_BASE}/auth/logout`,
    ME:              `${API_BASE}/auth/me`,
    FORGOT_PASSWORD: `${API_BASE}/auth/forgot-password`,
    RESET_PASSWORD:  `${API_BASE}/auth/reset-password`,
    GOOGLE:          `${API_BASE}/auth/google`,
  },
  PROJECTS: `${API_BASE}/projects`,
  TASKS:    `${API_BASE}/tasks`,
  CRM:      `${API_BASE}/crm`,
  TEAM:     `${API_BASE}/team`,
  DOCUMENTS:`${API_BASE}/documents`,
  REPORTS:  `${API_BASE}/reports`,
  AI:       `${API_BASE}/ai`,
} as const;

// ─── App Metadata ─────────────────────────────────
export const APP_META = {
  name:        'PSU CRM & PM System',
  shortName:   'PSU CRM',
  description: 'Enterprise CRM & Project Management for Pacific States University',
  university:  'Pacific States University',
  founded:     1928,
  location:    'Los Angeles, CA',
  foundation:  'By Konkuk University Foundation',
  author:      'Roise Uddin',
  version:     '1.0.0',
  github:      'https://github.com/roiseuddinrasel/psu-crm-pm',
} as const;
